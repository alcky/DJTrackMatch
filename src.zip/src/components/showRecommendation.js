import React ,{useState,useEffect} from 'react'

export default function ShowRecommendation(props) {

    const [musiclist,setmusiclist] = useState([]);

    useEffect(()=>{
        
        fetch(`https://api.spotify.com/v1/recommendations?seed_artists=${props.artist}&seed_tracks=${props.track}&min_energy=0.4&min_popularity=50&market=US`,{
            method:"GET",
            headers:{
                'Authorization':"Bearer BQCFJORw6GIwQ4aM7SzmUKKymtSPI9fXDkScXG-3FGQe9T5lZ1pr_lKQoI7c9ZGJfjs3XUJPfaH56o2L0wN9HGIHHlCmVvwQEavn4R4cDkNgLbm1DuenHW2QD0_CjiiTpD-9TmYhHv4lngSX6GAZEM7lyHhPwLR86uuzvxhSTwNKIXwBW2zZmgtk4gKwJwBEExbNGS2HTyIDDcpT_f5WZeZ0WnyAZBea0UKioXVxicjdD0ZVCk7KPMymo0lQqznD-Q7AAWe7Ir-3KuZvAl6wEQ"
            }
        }).then(musicdata=>{musicdata.json().then((data)=>{console.log(data);setmusiclist(data.tracks)})})
    },[])
    
    return (
        
        <div>
            {musiclist.map(music => <li key={music.id}><p>{music.name}</p></li>)}
        </div>
    )
    
}