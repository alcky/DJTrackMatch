import React ,{useState} from 'react'
import Music from './Music';
import ShowRecommendation from './showRecommendation'

export default function SearchAndShow() {

    const [musiclist,setmusiclist] = useState([]);
    const [searchtext, setsearchtext] = useState("")

    const handleChange=(e) =>{
        console.log(e)
        setsearchtext(e.target.value)
    }

    const handleSubmit=(e)=>{
        
        e.preventDefault();
        fetch(`https://api.spotify.com/v1/search?q=${searchtext}&type=track,artist`,{
            method:"GET",
            headers:{
                'Authorization':"Bearer BQCFJORw6GIwQ4aM7SzmUKKymtSPI9fXDkScXG-3FGQe9T5lZ1pr_lKQoI7c9ZGJfjs3XUJPfaH56o2L0wN9HGIHHlCmVvwQEavn4R4cDkNgLbm1DuenHW2QD0_CjiiTpD-9TmYhHv4lngSX6GAZEM7lyHhPwLR86uuzvxhSTwNKIXwBW2zZmgtk4gKwJwBEExbNGS2HTyIDDcpT_f5WZeZ0WnyAZBea0UKioXVxicjdD0ZVCk7KPMymo0lQqznD-Q7AAWe7Ir-3KuZvAl6wEQ"
            }
        }).then(musicdata=>{musicdata.json().then((data)=>{console.log(data);setmusiclist(data.tracks.items)})})
    }
    
    return (
        
        <div>
            <input type="text" onChange={handleChange}/>
            <button type="submit" onClick={handleSubmit}>Submit</button>
            {musiclist && musiclist.map(music => {return(<Music data={music}/>)})}
        </div>
    )
}
