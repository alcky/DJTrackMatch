import React,{useState} from 'react';
import ShowRecommendation from './showRecommendation'

export default function Music(props) {
    const [bpm, setbpm] = useState({key:"Not here",bpm:"Not found"});
    const [rec, setrec] = useState({recommendation:"No recommendation"});
    const [reco,setreco] = useState(false)

    const getBPM = (e) =>{
        e.preventDefault();
        fetch(`https://api.spotify.com/v1/audio-analysis/${props.data.id}`,{
            method:"GET",
            headers:{
                "Authorization":"Bearer BQCFJORw6GIwQ4aM7SzmUKKymtSPI9fXDkScXG-3FGQe9T5lZ1pr_lKQoI7c9ZGJfjs3XUJPfaH56o2L0wN9HGIHHlCmVvwQEavn4R4cDkNgLbm1DuenHW2QD0_CjiiTpD-9TmYhHv4lngSX6GAZEM7lyHhPwLR86uuzvxhSTwNKIXwBW2zZmgtk4gKwJwBEExbNGS2HTyIDDcpT_f5WZeZ0WnyAZBea0UKioXVxicjdD0ZVCk7KPMymo0lQqznD-Q7AAWe7Ir-3KuZvAl6wEQ"
                }
        }).then(res=>{res.json().then(data=>{
            console.log(data);
            setbpm({key:data.track.key,bpm:data.track.tempo})
        })});
        
    }

    const handleClick = (e) =>{
        e.preventDefault();
        setreco(true)
    }

    return (
        <div>
            <p>{props.data.name}</p>
            
            <button onClick={getBPM}>BPM & KEY </button>
            {(bpm) ?(<div><p>{bpm.key} is the key & {bpm.bpm} is tempo</p>
                        <button onClick={handleClick}>Recommendations</button>
                        </div>
            ):""}

            {reco && <ShowRecommendation artist={props.data.artists[0].id} track={props.data.id}/>}
            
        </div>
    )
}
