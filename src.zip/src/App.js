import React from 'react';
import logo from './logo.svg';
import './App.css';
import SearchAndShow from './components/SearchAndShow';
import Rec from './components/showRecommendation'

function App() {
  return (
    <div className="App">
      <SearchAndShow/> </div>
  );
}

export default App;
